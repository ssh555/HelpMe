#ifndef PATIENTFORM_H
#define PATIENTFORM_H

#include <QWidget>
#include<QIcon>

namespace Ui {
class PatientForm;

}

class PatientForm : public QWidget
{
    Q_OBJECT

public:
    explicit PatientForm(int age = 32, QString name = "ssh", int number = 34, QString date = "feb", QString pic_str = ":/picture/P1.jpg", QWidget *parent = nullptr);
    ~PatientForm();

private:

    Ui::PatientForm *ui;
};

#endif // PATIENTFORM_H
