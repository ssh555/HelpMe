#include "widget.h"
#include "ui_widget.h"
#include<QPushButton>
#include<QLineEdit>
#include<QImage>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    patient1 = new PatientForm(40,"Gin",111 , "2021/08/21", ":/picture/P1.jpg",this);
    patient1->setObjectName("病人选择查看界面1");
    patient1->setGeometry(100, 100,300, 400);
    patient1->show();



    patient2 = new PatientForm(46,"Vodka", 222, "2021/08/24", ":/picture/P2.jpg", this);
    patient2->setObjectName("病人选择查看界面2");
    patient2->setGeometry(450, 100, 300, 400);
    patient2->show();

    patient3 = new PatientForm(50,"Vermouth", 333, "2021/08/11", ":/picture/P3.jpg", this);
    patient3->setObjectName("病人选择查看界面3");
    patient3->setGeometry(800, 100, 300, 400);
    patient3->show();

    patient4 = new PatientForm(25,"Sherry", 444, "2021/08/17", ":/picture/P4.jpg", this);
    patient4->setObjectName("病人选择查看界面4");
    patient4->setGeometry(100, 500, 300, 400);
    patient4->show();

    patient5 = new PatientForm(27,"Calvados", 555, "2021/08/28",":/picture/P5.jpg", this);
    patient5->setObjectName("病人选择查看界面4");
    patient5->setGeometry(450, 500, 300, 400);
    patient5->show();

    patient6 = new PatientForm(23,"Chianti", 666, "2021/08/21", ":/picture/P6.jpg", this);
    patient6->setObjectName("病人选择查看界面4");
    patient6->setGeometry(800, 500, 300, 400);
    patient6->show();

    QPushButton *quit = new QPushButton(tr("quit"),this);
    quit->setGeometry(1100, 30, 80, 50);
    connect(quit, SIGNAL(clicked()), this, SLOT(close()));
    quit->show();

    QLineEdit *maintitle = new QLineEdit(tr("病人选择界面"),this);
    maintitle->setGeometry(420, 10, 360, 80);
    maintitle->setFont(QFont(tr("Consolas"),  28));
    maintitle->setStyleSheet("{image: url(:/picture/background.jpg);}");
}

Widget::~Widget()
{
    delete ui;
}

