#include "widget.h"
#include"patientform.h"
#include <QApplication>
#include<QPushButton>
#include <QtGui>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.resize(1200,900);
    w.setWindowTitle("’救救我‘无人值守监控系统");
    w.setStyleSheet("{image: url(:/picture/background.jpg);}");




    w.show();
    return a.exec();
}
